-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2017 at 03:53 AM
-- Server version: 5.6.33-0ubuntu0.14.04.1
-- PHP Version: 5.6.31-6+ubuntu14.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `MobileComputing`
--
CREATE DATABASE IF NOT EXISTS `MobileComputing` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `MobileComputing`;

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE IF NOT EXISTS `author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(150) NOT NULL,
  `lname` varchar(150) NOT NULL,
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`author_id`, `fname`, `lname`) VALUES
(1, 'Jenny', 'Preece'),
(2, 'Helen', 'Sharp'),
(3, 'Addison-Wesley', 'Longman'),
(4, 'Erich ', 'Gamma'),
(5, 'Robert', 'Sedgewick'),
(6, 'Ethan', 'Brown');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(150) NOT NULL,
  `title` varchar(150) NOT NULL,
  `date_of_publication` timestamp NULL DEFAULT NULL,
  `count_pages` int(11) DEFAULT NULL,
  `publisher_id` int(11) NOT NULL,
  `rate` int(11) DEFAULT NULL,
  `cover_src` varchar(150) DEFAULT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`book_id`,`publisher_id`),
  KEY `fk_book_publisher_idx` (`publisher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `isbn`, `title`, `date_of_publication`, `count_pages`, `publisher_id`, `rate`, `cover_src`, `description`) VALUES
(1, '12132323', 'Software engineering', '0000-00-00 00:00:00', 290, 1, 1, 'https://images-eu.ssl-images-amazon.com/images/I/61vOhQuV9fL._AC_US436_QL65_.jpg', 'The Fundamental Practice of Software Engineering\r\n\r\nSoftware Engineering introduces students to the overwhelmingly important subject of software programming and development. In the past few years, computer systems have come to dominate not just our technological growth, but the foundations of our world’s major industries. This text seeks to lay out the fundamental concepts of this huge and continually growing subject area in a clear and comprehensive manner.\r\n\r\n\r\nThe Tenth Edition contains new information that highlights various technological updates of recent years, providing students with highly relevant and current information. Sommerville’s experience in system dependability and systems engineering guides the text through a traditional plan-based approach that incorporates some novel agile methods. The text strives to teach the innovators of tomorrow how to create software that will make our world a better, safer, and more advanced place to live.'),
(2, 'asd231323', 'Interaction Design', '0000-00-00 00:00:00', 584, 2, 45, 'https://images-eu.ssl-images-amazon.com/images/I/51a5Wfy+tQL._AC_US436_QL65_.jpg', 'Hugely popular with students and professionals alike, Interaction Design is an ideal resource for learning the interdisciplinary skills needed for interaction design, human computer interaction, information design, web design and ubiquitous computing. \r\n\r\nThis text offers a cross–disciplinary, practical and process–oriented introduction to the field, showing not just what principles ought to apply to interaction design, but crucially how they can be applied.\r\n\r\nAn accompanying website contains extensive additional teaching and learning material including slides for each chapter, comments on chapter activities and a number of in–depth case studies written by researchers and designers.'),
(3, '123', 'Algorithms', '2017-10-26 04:00:00', 200, 1, 4, 'https://images-na.ssl-images-amazon.com/images/I/41%2BpJNrGujL._SX359_BO1,204,203,200_.jpg', 'This fourth edition of Robert Sedgewick and Kevin Wayne’s Algorithms is the leading textbook on algorithms today and is widely used in colleges and universities worldwide. This book surveys the most important computer algorithms currently in use and provides a full treatment of data structures and algorithms for sorting, searching, graph processing, and string processing--including fifty algorithms every programmer should know. In this edition, new Java implementations are written in an accessible modular programming style, where all of the code is exposed to the reader and ready to use.\r\n\r\n \r\n\r\nThe algorithms in this book represent a body of knowledge developed over the last 50 years that has become indispensable, not just for professional programmers and computer science students but for any student with interests in science, mathematics, and engineering, not to mention students who use computation in the liberal arts.\r\n\r\n \r\n\r\nThe companion web site, algs4.cs.princeton.edu, contains\r\n\r\nAn online synopsis\r\nFull Java implementations\r\nTest data\r\nExercises and answers\r\nDynamic visualizations\r\nLecture slides\r\nProgramming assignments with checklists\r\nLinks to related material\r\nThe MOOC related to this book is accessible via the "Online Course" link at algs4.cs.princeton.edu. The course offers more than 100 video lecture segments that are integrated with the text, extensive online assessments, and the large-scale discussion forums that have proven so valuable. Offered each fall and spring, this course regularly attracts tens of thousands of registrants.\r\n\r\n \r\n\r\nRobert Sedgewick and Kevin Wayne are developing a modern approach to disseminating knowledge that fully embraces technology, enabling people all around the world to discover new ways of learning and teaching. By integrating their textbook, online content, and MOOC, all at the state of the art, they have built a unique resource that greatly expands the breadth and depth of the educational experience.'),
(4, '123456', 'Web Development with Node and Express', '2017-10-10 04:00:00', 314, 2, 2, 'https://images-eu.ssl-images-amazon.com/images/I/51-U0v0J8DL._AC_US436_QL65_.jpg', 'Learn how to build dynamic web applications with Express, a key component of the Node/JavaScript development stack. In this hands-on guide, author Ethan Brown teaches you the fundamentals through the development of a fictional application that exposes a public website and a RESTful API. You’ll also learn web architecture best practices to help you build single-page, multi-page, and hybrid web apps with Express.\r\n\r\nExpress strikes a balance between a robust framework and no framework at all, allowing you a free hand in your architecture choices. With this book, frontend and backend engineers familiar with JavaScript will discover new ways of looking at web development.\r\n\r\nCreate webpage templating system for rendering dynamic data\r\nDive into request and response objects, middleware, and URL routing\r\nSimulate a production environment for testing and development\r\nFocus on persistence with document databases, particularly MongoDB\r\nMake your resources available to other programs with RESTful APIs\r\nBuild secure apps with authentication, authorization, and HTTPS\r\nIntegrate with social media, geolocation, and other third-party services\r\nImplement a plan for launching and maintaining your app\r\nLearn critical debugging skills\r\nThis book covers Express 4.0.'),
(5, '123456', 'Design patterns : elements of reusable object-oriented software', '2017-10-02 04:00:00', 100, 1, 5, 'https://images-eu.ssl-images-amazon.com/images/I/51szD9HC9pL._AC_US436_QL65_.jpg', 'Presents a catalog of simple solutions to commonly occurring design problems. These 23 patterns allow designers to create more reusable designs without having to rediscover the design solutions themselves. The authors begin by describing what patterns are, and how they can help you design object-oriented software.');

-- --------------------------------------------------------

--
-- Table structure for table `book_author`
--

CREATE TABLE IF NOT EXISTS `book_author` (
  `book_author_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  PRIMARY KEY (`book_author_id`,`book_id`,`author_id`),
  KEY `fk_book_author_book1_idx` (`book_id`),
  KEY `fk_book_author_author1_idx` (`author_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `book_author`
--

INSERT INTO `book_author` (`book_author_id`, `book_id`, `author_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 3),
(5, 3, 5),
(6, 4, 6),
(4, 5, 4);

-- --------------------------------------------------------

--
-- Table structure for table `book_category`
--

CREATE TABLE IF NOT EXISTS `book_category` (
  `book_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`book_category_id`,`book_id`,`category_id`),
  KEY `fk_book_category_book1_idx` (`book_id`),
  KEY `fk_book_category_category1_idx` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `book_category`
--

INSERT INTO `book_category` (`book_category_id`, `book_id`, `category_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `book_review`
--

CREATE TABLE IF NOT EXISTS `book_review` (
  `book_review_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(1500) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL,
  `date_of_review` timestamp NULL DEFAULT NULL,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `book_id` int(11) NOT NULL,
  PRIMARY KEY (`book_review_id`,`language_id`,`book_id`),
  KEY `fk_book_review_language1_idx` (`language_id`),
  KEY `fk_book_review_book1_idx` (`book_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `book_review`
--

INSERT INTO `book_review` (`book_review_id`, `comment`, `rate`, `date_of_review`, `language_id`, `book_id`) VALUES
(1, 'Great!', 1, '0000-00-00 00:00:00', 1, 1),
(2, 'Good', 2, '0000-00-00 00:00:00', 1, 1),
(3, 'Not bad', 2, '0000-00-00 00:00:00', 2, 2),
(4, 'abc', 2, '2017-10-20 09:28:58', 1, 1),
(5, 'abc', 1, '2017-10-20 10:02:40', 1, 2),
(6, 'the best book in my life', 1, '2017-10-20 10:03:24', 1, 2),
(7, 'the best book in my life', 1, '2017-10-22 18:40:45', 1, 2),
(8, 'the best book in my life', 2, '2017-10-22 18:40:52', 1, 2),
(9, 'the best book in my life', 2, '2017-10-22 18:43:56', 1, 2),
(10, NULL, 3, '2017-10-22 18:44:35', 1, 1),
(11, NULL, 0, '2017-10-22 19:12:14', 1, 1),
(12, NULL, 3, '2017-10-22 19:13:52', 1, 1),
(13, 'this is a long review of sh oh by oh sh oh check oh fk oh CU I''ll KC TV no oh Rh h oh DC by uh DJ oh ft uh boo oh Rh in uh hg GH oh g the j hi ok VG tv j ok ok gg GB ok ok ju GG ett dl öl ideell utan ugn och ords ej ligger typ idé till IF so of the Jr do oh well if do of DK if en oh do of to IDK if fk', 0, '2017-10-22 19:18:05', 1, 1),
(14, 'test review 1', 3, '2017-10-22 19:29:23', 1, 1),
(15, 'test review 2', 3, '2017-10-22 19:33:05', 1, 1),
(16, 'test review 3', 3, '2017-10-22 19:37:32', 1, 1),
(17, 'test 123', 3, '2017-10-25 16:44:32', 1, 1),
(18, 'test 123', 3, '2017-10-25 16:45:02', 1, 1),
(19, 'test 123', 3, '2017-10-25 16:46:10', 1, 1),
(20, 'test 123', 3, '2017-10-25 16:46:13', 1, 1),
(21, 'test 123456', 3, '2017-10-25 16:48:11', 1, 1),
(22, 'test 123456', 3, '2017-10-25 16:48:14', 1, 1),
(23, 'test 123456789', 3, '2017-10-25 16:51:54', 1, 1),
(24, 'test 123456789', 3, '2017-10-25 16:51:57', 1, 1),
(25, 'test 111111', 3, '2017-10-25 16:56:32', 1, 1),
(26, 'test 111111', 3, '2017-10-25 16:56:34', 1, 1),
(27, 'test 111111', 3, '2017-10-25 17:03:46', 1, 1),
(28, 'test 111111', 3, '2017-10-25 17:03:49', 1, 1),
(29, 'test 222222222', 3, '2017-10-25 17:05:01', 1, 1),
(30, 'test 222222222', 3, '2017-10-25 17:05:03', 1, 1),
(31, 'test 222222222', 3, '2017-10-25 17:06:11', 1, 1),
(32, 'test 222222222', 3, '2017-10-25 17:06:13', 1, 1),
(33, 'test 222222222345', 3, '2017-10-25 17:06:51', 1, 1),
(34, 'test 222222222345', 3, '2017-10-25 17:06:54', 1, 1),
(35, 'test 2222222223456766', 3, '2017-10-25 17:07:08', 1, 1),
(36, 'test 2222222223456766', 3, '2017-10-25 17:07:10', 1, 1),
(37, 'hfhöv oh hg FG ok DB', 3, '2017-10-26 15:39:33', 1, 4),
(38, 'hfhöv oh hg FG ok DB', 3, '2017-10-26 15:39:35', 1, 4),
(39, 'hfhöv oh hg FG ', 3, '2017-10-26 15:39:49', 1, 4),
(40, 'hfhöv oh hg FG ', 3, '2017-10-26 15:39:52', 1, 4),
(41, 'ttt', 4, '2017-10-26 15:41:52', 1, 4),
(42, 'ttt', 4, '2017-10-26 15:41:54', 1, 4),
(43, 'testing book 999', 4, '2017-10-26 15:54:32', 1, 1),
(44, 'testing book 999', 4, '2017-10-26 15:54:35', 1, 1),
(45, 'test review 789789', 1, '2017-10-26 15:57:03', 1, 1),
(46, 'qqqqqwwwww', 4, '2017-10-26 15:59:06', 1, 1),
(47, 'qqqqqwwwwwrrrrr', 4, '2017-10-26 15:59:41', 1, 1),
(48, 'Test', 2, '2017-10-26 20:45:49', 1, 2),
(49, 'Test', 2, '2017-10-26 20:48:17', 1, 2),
(50, 'very good book', 3, '2017-10-26 21:06:03', 1, 3),
(51, 'I recommend this book to anyone who''s trying to get into design patterns or just refresh their memory on the topic.', 4, '2017-10-27 06:42:57', 1, 5),
(52, 'tjgff ', 4, '2017-10-27 07:15:51', 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(150) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'IT'),
(2, 'Interaction');

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `language_name` varchar(150) NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`language_id`, `language_name`) VALUES
(1, 'English'),
(2, 'Swedish');

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE IF NOT EXISTS `publisher` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(250) NOT NULL,
  PRIMARY KEY (`publisher_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`publisher_id`, `publisher_name`) VALUES
(1, 'publisher1'),
(2, 'publisher2');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `hash` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `hash`, `email`) VALUES
(2, 'oscar', '$2a$10$qbQsjo4VNRg7NBMgoD7MhO63JpJ60CN5AADoKnyoWoSJDqCIBoVja', 'oscar'),
(3, 'wissam', '$2a$10$yIcfFZtmBToAiJMq9Eb0UeX8t5xjan.rPLCj3s6ToZJ9jKt12FR.2', 'wwweeerrrtttyyyuuuiiiooo@gmail.com'),
(4, 'oscar', '$2a$10$TZTC3ldH8nhKyI4sIsYXkuSQAH6z2tJRmpGtYxdBJ8U3sc0UAxmGi', 'oscar');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `fk_book_publisher` FOREIGN KEY (`publisher_id`) REFERENCES `publisher` (`publisher_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `book_author`
--
ALTER TABLE `book_author`
  ADD CONSTRAINT `fk_book_author_author1` FOREIGN KEY (`author_id`) REFERENCES `author` (`author_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_book_author_book1` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `book_category`
--
ALTER TABLE `book_category`
  ADD CONSTRAINT `fk_book_category_book1` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_book_category_category1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `book_review`
--
ALTER TABLE `book_review`
  ADD CONSTRAINT `fk_book_review_book1` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_book_review_language1` FOREIGN KEY (`language_id`) REFERENCES `language` (`language_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
